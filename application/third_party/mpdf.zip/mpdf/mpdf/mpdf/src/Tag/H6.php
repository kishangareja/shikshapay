<?php

namespace Mpdf\Tag;

class H6 extends BlockTag
{


}
